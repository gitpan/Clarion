To install Clarion, run install.bat
To uninstall Clarion, run uninstall.bat
